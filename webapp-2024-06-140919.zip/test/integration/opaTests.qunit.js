/* global QUnit */

sap.ui.require(["task/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
