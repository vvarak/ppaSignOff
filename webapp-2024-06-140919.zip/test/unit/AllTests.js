sap.ui.define([
	"task/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
